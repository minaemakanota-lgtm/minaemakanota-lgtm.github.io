document.getElementById("testBtn").addEventListener("click",function(){
  const s=document.getElementById("status");
  s.textContent="الصفحة تعمل بشكل صحيح ✓";
});
